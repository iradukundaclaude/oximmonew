<script>
function sendMail() {
    // Get form data
    var formData = new FormData(document.getElementById('contactForm'));

    // Send AJAX request
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'mail.php', true);
    xhr.onload = function() {
        if (xhr.status == 200) {
            // Handle the response
            if (xhr.responseText === 'success') {
                document.getElementById('statusMessage').innerHTML = 'Message has been sent successfully.';
            } else if (xhr.responseText === 'error') {
                document.getElementById('statusMessage').innerHTML = 'Failed to send message. Please try again.';
            }
        } else {
            document.getElementById('statusMessage').innerHTML = 'Error: ' + xhr.statusText;
        }
    };

    // Set up the form data and send the request
    xhr.send(formData);
}
</script>