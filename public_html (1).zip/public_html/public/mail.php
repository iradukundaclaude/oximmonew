<?php
include('PHPMailer/src/MailerConfig.php');
use PHPMailer\PHPMailer\PHPMailer;

// Check if it's a POST request
if (POST_REQUEST) {
    $names = $_POST["full_name"];
    $full_name = $_POST['full_name'];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $message = $_POST["messages"];

    $mail = new PHPMailer(true);

    try {
        // Check if the message already exists
        $check_query = "SELECT * FROM `user_message` WHERE `full_name`='$full_name' AND `phone`='$phone' AND `email`='$email' AND `messages`='$message'";
        $result = $conn->query($check_query);

        if ($result->num_rows > 0) {
            $response = ['status' => 'error', 'message' => 'Message is already sent.'];
        } else {
            // Send the message
            $insert_query = "INSERT INTO `user_message` (`full_name`, `phone`, `email`, `messages`) VALUES ('$full_name', '$phone', '$email', '$message')";

            if ($conn->query($insert_query) === TRUE) {
                // Send message to email
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'catcherwe@gmail.com';
                $mail->Password   = 'ojptywtrspeuarai';
                $mail->SMTPSecure = 'tls';
                $mail->Port       = 587;

                // Recipients
                $mail->setFrom($email, 'company');
                $mail->addAddress('catcherwe@gmail.com', 'oximo');
                $mail->addReplyTo($email, 'Client');

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'TESTING SMTP';
                $mail->Body    = "This is the HTML message body\n<b>Name: $names\nEmail: $email\nMessage:\n$message</b>";

                $mail->send();
                
                $response = ['status' => 'success', 'message' => 'Message has been sent.'];
            } else {
                $response = ['status' => 'error', 'message' => "Error: " . $insert_query . "<br>" . $conn->error];
            }
        }

        // Send JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();
    } catch (Exception $e) {
        $response = ['status' => 'error', 'message' => "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"];
        
        // Send JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();
    }
}

// Close database connection
$conn->close();
?>
