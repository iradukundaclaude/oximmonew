<?php include('../public/database/dbase_connect.php') ?>
<?php include('../public/common_function/function.php'); ?>
<?php include('header.php'); ?>
   <!---show view more on engineering projects ---->
       <div class="content">
          <!-- fetching projects using function -->
          <?php
            engineeringProjects();
          ?>
              <div class="inputbox">
                <a href="contact.php"><input type="Submit" name="" value="Ask More On This Project" style="background-color:#00ccff;"></a>
              </div>
           </div>
        </div>
        <!-- include footer -->
        <?php include('../public/footer/footer.php') ?>
    </body>
</html>