  <?php
    include('database/dbase_connect.php');
    include('common_function/function.php');
    include('header.php');
   
  ?>

        <style>
           .row{
               margin:0;
               width:0 auto;
               height:0 auto;
               background-color:white;
           }
           .card{
              width:100%;
              height:0 auto;
              display:flex;
              justify-content:center;
              align-items:center;
              margin-top:30px;
              box-shadow: 10px 10px 5px black; 
           }
           .card img{
               width:50%;
               height:50%; 
               position:flex;
           }
           .card-body{
               background-color:rgb(120, 120, 120);
               width:600px;
               height:470px;
               margin-left:4px;
           }.project-description{
              margin:0;                
           }
           .project-description h4,p{
              text-align:center;
              margin-top:20px;
              color:black;
           }
        </style>
        <!-- showing searching page -->
        <div class="row">
            <div class="column">
            <?php
function search()
{
    global $conn,$DATA_QUERY;

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $searching_data = $_GET['search_data'];
        require 'data.php';
        $query =$DATA_QUERY;

        $result_search = $conn->query($query);

        $rows = array();

        while ($row = $result_search->fetch_assoc()) {
            $rows[] = $row;
            $project_id = $row['project_id'];
            $project_title = $row['project_name'];
            $project_description = $row['project_description'];
            $project_keywords = $row['project_keywords'];
            $project_location = $row['location'];
            $project_landscale = $row['landscale'];
            $project_year = $row['year'];
            $image = $row['image1'];

            echo '
            <div class="card">
                <img src="./images/' . $image . '" class="card-img-top" alt="..." style="width:80%;">
                <div class="card-body">
                    <div class="project-description">
                        <h4>PROJECT NAME: ' . $project_title . '</h4>
                        <p>LOCATION: ' . $project_location . '</p>
                        <p>LAND SCALE: ' . $project_landscale . '</p>
                    </div>
                    <div class="inputbox">
                        <a href="inter_project_viewmore.php?interior_data=' . $project_id . '">
                            <input type="Submit" name="view_more" value="View more" style="color:#000000;background-color:#00CCFF;">
                        </a>
                    </div>
                </div>
            </div>';
        }

        if (empty($rows)) {
            echo "
            <div style='height:400px;'>
                <h2 class='text-center text-danger' style='color:#e91e63; text-align:center; margin-top:100px;'>
                    No results match. No projects found!
                </h2>
            </div>";
        }
    }
}

search();
?>
            </div>
        </div>
        <!---- end of searching page ---->      
        <!-- include footer -->
        <?php include('footer/footer.php') ?>
    </body>
</html>

                                                                                             

