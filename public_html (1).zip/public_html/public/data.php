<?php
$DATA_QUERY = '
    SELECT id AS project_id, project_name, project_description, project_keywords, location, landscale, year, image1
    FROM interior_design
    WHERE project_keywords LIKE \'%' . $searching_data . '%\'';

$DATA_QUERY .= '
    UNION
    
    SELECT id AS project_id, project_name, project_description, project_keywords, location, landscale, year, image1
    FROM engineering_project
    WHERE project_keywords LIKE \'%' . $searching_data . '%\'';

$DATA_QUERY .= '
    UNION
    
    SELECT id AS project_id, project_name, project_description, project_keywords, location, landscale, year, image1
    FROM architecture_project
    WHERE project_keywords LIKE \'%' . $searching_data . '%\'';

$DATA_QUERY .= '
    UNION
    
    SELECT id AS project_id, project_name, project_description, project_keywords, location, project_landscale, year, image1
    FROM project_management
    WHERE project_keywords LIKE \'%' . $searching_data . '%\'';

$DATA_QUERY .= '
    UNION
    
    SELECT id AS project_id, project_name, project_description, project_keywords, location, landscale, year, image1
    FROM master_planning
    WHERE project_keywords LIKE \'%' . $searching_data . '%\'';

$DATA_QUERY .= '
    UNION
    
    SELECT id AS project_id, project_name, project_description, project_keywords, location, landscale, year, image1
    FROM engineering_project
    WHERE project_keywords LIKE \'%' . $searching_data . '%\'';
