
<?php include('../public/database/dbase_connect.php') ?>
<?php include('../public/common_function/function.php'); ?>
<?php include('header.php'); ?>
         <style>
          body, html {
          margin: 0;
          padding: 0;
          width: 100%;
          height: 100%;
         
        }
        
           .bg-light{
               justify-content:center;
               justify:content;
               text-align:center;
               margin:0 auto;
               width:0 auto;
               background-color:rgb(120, 120, 120);
               padding-top:1px;
               box-shadow: 0px 5px 5px black;    
           }
           .bg-light h3{
               color: hsl(0, 0%, 0%);
               text-shadow: 1px 1px 2px white, 0 0 25px yellow, 0 0 5px yellow;
               text: center;
           }
           .bg-light p{
              color:white;
              text-size:16px;
           }
           .row{
               margin:0;
               width:0 auto;
               height:0 auto;
               background-color:white;
           }
           .card{
              width:100%;
              height:0 auto;
              display:flex;
              justify-content:center;
              align-items:center;
              margin-top:30px;
              box-shadow: 0px 5px 5px black; 
           }
           .card img{
               width:50%;
               height:50%; 
               position:flex;
           }
           .card-body{
               background-color:rgb(120, 120, 120);
               width:600px;
               height:470px;
               margin-left:4px;
           }.project-description{
              margin:0;                
           }
           .project-description h4,p{
              text-align:center;
              margin-top:20px;
              color:black;
           }
        </style>
        <!-- showing slides images -->
        <div data-elementor-type="wp-page" data-elementor-id="1125" class="elementor elementor-1125">
            <section class="elementor-section elementor-top-section elementor-element elementor-element-76e2407 elementor-section-full_width elementor-section-height-default elementor-section-height-default tf-sticky-section tf-sticky-no" data-id="76e2407" data-element_type="section" data-settings="{&quot;tf_sticky&quot;:&quot;no&quot;}">
                <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a7a84b2" data-id="a7a84b2" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-b0420f7 elementor-widget elementor-widget-sina_content_slider" data-id="b0420f7" data-element_type="widget" data-widget_type="sina_content_slider.default">
                                <div class="elementor-widget-container">
                                    <div class="wrapper-container w-container" style="height:600px; width: 100%;">
                                       <div class="hero-section">
                                           <div data-delay="3500" data-animation="cross" class="hero-slider w-slider" data-autoplay="true" data-easing="ease-in-out" data-hide-arrows="false" data-disable-swipe="false" data-autoplay-limit="0" data-nav-spacing="3" data-duration="2000" data-infinite="true">
                                               <div class="w-slider-mask">
                                                    <div class="slide w-slide"></div>
                                                    <div class="slide-2 w-slide"></div>
                                                    <div class="slide-3 w-slide"></div>
                                                    <div class="slide-4 w-slide"></div>
                                                    <div class="slide-6 w-slide"></div>
                                                    <div class="slide-7 w-slide"></div>
                                                    <div class="slide-8 w-slide"></div>
                                                    <div class="slide-5 w-slide"></div>
                                                    <div class="slide-9 w-slide"></div>
                                               </div>
                                               <div class="left-arrow w-slider-arrow-left">
                                                  <div class="icon-4 w-icon-slider-left"></div>
                                               </div>
                                               <div class="right-arrow w-slider-arrow-right">
                                                  <div class="icon-3 w-icon-slider-right"></div>
                                               </div>
                                                   <div class="slide-nav-2 w-slider-nav"></div>
                                               </div>
                                           </div>
                                       </div>
                                       <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=5f2c1f613a983985dbf193bb" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
                                       <script src="https://assets-global.website-files.com/5f2c1f613a983985dbf193bb/js/webflow.e1ed2e247.js" type="text/javascript"></script>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>  
                </div>
            </section>
            <!---- first part ---->           
            <div class="bg-light">
               <h3> All Our Projects</h3>
               <p>This project exceeded all expectations, delivering outstanding results that will undoubtedly leave a lasting impact<br>
                A truly remarkable project, demonstrating exceptional teamwork and innovation, setting a new standard for excellence.<br>
                Outstanding work! This project showcases a level of dedication and quality that is truly commendable, and I highly recommend their services.</p>
            </div>
            <!------  projects image and description ---->
            <div class="row">
              <div class="column">
                <?php
                /// calling function to show projects
                view_allproject();
                ?>
              </div>
            </div>
        </div>
        <!---- end of project image and description ---->      
        <!-- include footer -->
        <?php include('../public/footer/footer.php') ?>
      </div>
    </body>
</html>

                                                                                             

