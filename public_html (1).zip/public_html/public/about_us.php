<?php include('../public/database/dbase_connect.php') ?>
<?php include('../public/common_function/function.php'); ?>
<?php include('header.php'); ?>
         <style>
             body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
          }
          .header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .about-content {
            text-align: center;
        }
        .about-image {
            max-width: 100%;
            height: auto;
        }
        p {
            color: black;
            font-size: 18px;
            line-height: 1.6;
        }.row{
            width: 48%;
            height: 80%;
        }
      .container {
      display: flex;
    }

    .column_1 {
    flex: 1;
    padding: 20px;
    flex: 1;
    padding: 10px;
    border: 1px solid #ccc;
    text-align: center;
    }.head{
            text-align: center;
        }
      .row {
    display: flex;
    justify-content: space-between;
    margin-left: 12%;
    margin-right:0 auto; 
}

/* Media query for responsive design */
@media (max-width: 768px) {
    .row {
        flex-direction: column;
    }
    }.vertical-line{
        border-left: 2px solid #000; /* Adjust the width and color as needed */
        padding-left: 10px; 
    }
}
        .container {
            display: flex;
            border: 1px solid #ccc;
        }
        .column {
            flex: 1;
            padding: 20px;
            width:410px;
            height:0 auto;
            border-radius:15px;
            margin:7px;
            padding:20px 30px;
            position:relatve;
            background:rgba(255,255,255,0.5);
            box-shadow:10px 25px 25px rgba(0,0,0,0.2);
            transition:0.5s;
        }.column:hover{
            transform:scale(1.4);
            color:black;
            background:#fff;
            z-index:10000;
        }

        h2 {
            font-size: 18px;
            margin-bottom: 10px;
        }
        h2{
            text-align:center;
        }
        /******* customer testimonials ****/
        *{
         margin:0;
         padding:0;
         box-sizing:border-box;
     }
     .wrapper{
         /****** desgning container for our testimonials cards layout *****/
     
        background-color:white;
        min-height:100vh;
        margin:0 auto;
        display:flex;
        flex-direction:column; 
        justify-content:center;
        align-items:center;
        font-family:'raleway',sans-serif;
        color:black;
     }
     .wrapper h1{
         font-size:36px;
         font-weight:500;
         margin-top:25px;
         margin-bottom:20px;
         text-align:center;
         color:black;
     }.wrapper h5{
         font-size:20px;
         text-align:center;
         font-weight:300;
         margin-bottom:80px;
         color:black;
     }
     .cards{
         display:flex;
         justify-content:center;
         align-items:center;
         width:1200px;
         margin:0 auto;
         height:0 auto;
     }
     .card{
        width:410px;
        height:0 auto;
        border-radius:15px;
        margin:7px;
        padding:20px 30px;
        position:relatve;
        background:rgba(255,255,255,0.5);
        box-shadow:10px 25px 25px rgba(0,0,0,0.2);
        transition:0.5s;
     }
     .card img{
         height:90px;
         width:90px;
         border:2px solid #f2f2f2;
         border-radius:50%;
         left:100px;
         margin-top:-10px;
     }
     .card p{
         font-size:16px;
         margin-top:10px;
         margin-bottom:12px;
     }
     .card h2{
        font-weight:200;
        margin-bottom:6px;
     }
     .card h4{
        color:#333;
        font-weight:400;
        font-size:16px;
     }.card i{
         font-size:40px;
         margin-top:-10%;
         right:25px;
         color:#00CCFF;
         padding-left:70%;
     }.card:hover{
        transform:scale(1.4);
        color:black;
        background:#fff;
        z-index:10000;
     }
     /**** Responsive design *****/

     @media(max-width:768px){
       .cards{
          width:100%;
          flex-direction:column;
          flex-wrap:wrap;
       }
       .card{
           margin:20px 0;
       }
     }
   
    </style>
         <!-- SHOWING ABOUT US PAGE -->
        <div class="header">
           <h1>About Us</h1>
        </div>
        <div class="container">
           <div class="about-content">
               <img src="photo/about.jpg" alt="About Us Image" class="about-image">
                <p style="text-align: justify;">Welcome to our comprehensive architectural and design firm, where innovation, engineering expertise, project management, interior design, and master planning converge to shape the world around us.</p>
                <p style="text-align: justify;">With a strong commitment to excellence, we are your trusted partner in bringing architectural visions to life. Our multidisciplinary team of architects, engineers, and designers work collaboratively to deliver integrated solutions that not only enhance the visual appeal but also prioritize functionality and sustainability.</p>
                <p style="text-align: justify;">From the inception of a project to its completion, our holistic approach ensures a seamless journey. We pride ourselves on turning ideas into realities, from residential spaces to large-scale urban developments.</p>
                <p style="text-align: justify;">Let us be your partner in creating environments that are not only aesthetically captivating but also purposeful and future-ready. Welcome to a world where architecture and design are transformed into enduring legacies.</p>
           </div>
        </div>
        <div class="container">
           <div class="column">
              <h2 class="head">Our Mission</h2>
              <p>At OXIMO Construction, our mission is to transform the world through innovative and sustainable design and engineering solutions. Through collaborative efforts and a commitment to excellence, we aspire to be a driving force in shaping the future of architecture and infrastructure.</p>
           </div>
           <div class="column">
              <h2 class="head">Our Vission</h2>
              <p>Our vision is to be a globally recognized leader in the fields of architecture, engineering, project management, interior design, and master planning.we aim to redefine industry standards and set new benchmarks for excellence. Our ultimate vision is to inspire and leave a legacy of enduring, harmonious spaces that stand as testaments to human ingenuity and environmental stewardship.</p>
           </div>
        </div>
        <!------ showing customer testimonials ---->
        <div class="wrapper">
          <h1>Customer Testimonials</h1>
          <h5>Check what they say about us</h5>
          <div class="cards">
            <?php
            /// calling customer testimonials using functionality
            displaycustomer_testimonials()
            ?>
          </div>
        </div>
       </div> 
       <!-- include footer -->
       <?php include('../public/footer/footer.php') ?>
    </body>
</html>

                                                                                             
