<?php include('../public/database/dbase_connect.php') ?>
<?php include('../public/common_function/function.php'); ?>
<?php include('header.php'); ?>

<style>

      *{
         margin:0;
         padding:0;
      }
     body{
      background-color:#12172b;
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
     }
     .container {
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap');
    position:center;
    justify-content:center;
    width: 80%;
    height: auto;
    margin: 0 auto; /* Adjust as needed */
    color: white;
    background-color: #12172b;
    font-family: 'Poppins', sans-serif;
}

.headiing {
    color: black;
    margin-top: 10px;
    padding-left: 200px;
}

.profiles {
    padding-left: 6%;
    width: 85%;
    height: auto;
    display: flex;
    justify-content: center;
    margin-top: 80px;
    margin-bottom: 50px;
    flex-direction: column;
}

.profile {
    flex-basis: 400px;
    border: 1px solid #ccc;
    width: 85%;
    height: auto;
    border-radius: 15px;
    margin: 7px;
    padding: 18px 18px;
    position: relative;
    background: rgba(255, 255, 255, 0.5);
    box-shadow: 10px 25px 25px rgba(0, 0, 0, 0.2);
    transition: 0.5s;
    margin-left: 10px;
    flex-direction: column;
    justify-content: center;
}

.profile-img {
    position:center;
    width: 110px;
    height: 110px;
}

.profile:hover .profile-img {
    filter: grayscale(0);
    color: black;
    background: #fff;
}

.user-name {
    margin-top: 20px;
    font-size: 30px;
    text-align: center;
    color: white;
}

.profile h5 {
    font-size: 18px;
    font-weight: 100;
    letter-spacing: 3px;
    color: #ccc;
    text-align: center;
}

.paragraph {
    color: black;
    font-size: 20px;
    margin-top: 20px;
    text-align: justify;
    position: flex; /* Unsure about 'position:flex;' - check and modify if necessary */
    text-align: center;
}
/* For screens up to 768px width */
@media (max-width: 768px) {
    .headiing {
        padding-left: 20px; /* Adjust as needed */
    }
    .profiles {
        margin-top: 50px;
        margin-bottom: 30px;
    }
    .profile {
        flex-basis: calc(50% - 20px);
    }
    .profile-img {
        position:center;
        width: 100px;
        height: 100px;
    }
    .user-name {
        font-size: 24px;
    }
}

/* For screens between 769px and 1024px width */
@media (min-width: 769px) and (max-width: 1024px) {
    .headiing {
        padding-left: 50px; /* Adjust as needed */
    }
    .profiles {
        margin-top: 60px;
        margin-bottom: 40px;
    }
    .profile {
        flex-basis: calc(33.33% - 20px);
    }
}

/* For screens larger than 1024px width */
@media (min-width: 1025px) {
    /* Your default styles already defined above */
}

</style>

<!-- Rest of your HTML structure -->
<h1 class="headiing">Meet <span> With<span> Our<span> Team</h1>
<div class="container">
    <div class="profiles">
        <?php
        // calling function of team leadership
        displayleadership();
        ?>
    </div>
</div>
<!-- End of the leadership page -->

<!-- Include footer -->
<?php include('../public/footer/footer.php') ?>

  
                                                                                             

